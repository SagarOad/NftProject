import React from "react";

const ProductSection = () => {
  return (
    <div className="flex flex-wrap bg-[#fafafa] px-40">
      <div className="flex-1 flex justify-center items-center">
        <img
          src="https://portal.day2daywholesale.com/public/assets/img/products/thumb/1751108405763953.png"
          alt=""
        />
      </div>
   
      <div className="flex-1 flex justify-center items-center ">
        <div className="p-12">
        <div className="pb-7 mb-7 border-b">
          <h1 className="text-[30px] font-bold">
            JAM STRAWBERRY SADBOY (100ML)
          </h1>
          <p>
            Strawberry Jam Cookie 100ml shortfill e-liquid by Sad Boy combines
            there signature cookie flavour with a rich strawberry jam note. This
            combination of flavours creates a well-rounded dessert flavour.
          </p>
          <button className="text-[#e74c3c] font-bold">View Price</button>
        </div>

        <div className="pb-7 mb-7 border-b">
          <h1 className="text-base md:text-lg font-semibold mb-2.5 capitalize">
            STRENGTH
          </h1>
          <ul className="colors flex flex-wrap -me-3 items-center">
            <li className="cursor-pointer rounded-md border p-2 mb-2 flex justify-center items-center text-xsfont-semibold transition duration-200 ease-in-out hover:border-orange-500">3MG</li>
            <li className="cursor-pointer rounded-md border p-2 mb-2 flex justify-center items-center text-xsfont-semibold transition duration-200 ease-in-out hover:border-orange-500">3MG</li>
          </ul>
        </div>

        <div className="flex items-center space-s-4 md:pe-32 border-b py-8">
          <div className="group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11">
            <button
              className="  bg-gray-300 flex items-center border-2 border-[#121212] justify-center flex-shrink-0 h-full 
             duration-300 focus:outline-none w-10"
            >
              <span>-</span>
            </button>

            <span className=" bg-gray-300 w-24 border-2 border-[#121212] font-semibold  flex items-center justify-center h-full  cursor-default">
              1
            </span>

            <button
              className="  bg-gray-300 flex items-center border-2 border-[#121212] justify-center flex-shrink-0 h-full 
             duration-300 focus:outline-none w-10"
            >
              <span className="">+</span>
            </button>
          </div>

          <button className="bg-orange-500 text-white h-11 rounded-md px-12 ml-3">
            Add to cart
          </button>
        </div>

        <div className="py-7 mb-7 border-b">
          <ul>
            <li className="text-[14px]">
              <span className="font-semibold inline-block pe-2 mr-2">SKU:</span>{" "}
              JSTSB100ML
            </li>
            <li className="text-[14px]">
              <span className="font-semibold inline-block pe-2  mr-2">
                Category:
              </span>{" "}
              E-Liquids
            </li>
            <li className="text-[14px]">
              <span className="font-semibold inline-block pe-2  mr-2">
                Tags:
              </span>
              <a className="ml-2">SAD</a>
              <a className="ml-2">BOY</a>
              <a className="ml-2">LIQUID</a>
              <a className="ml-2">FLAVOUR</a>
            </li>
            <li className="text-[14px]">
              <span className="font-semibold inline-block pe-2  mr-2">
                Quality:
              </span>{" "}
              10
            </li>
            <li className="text-[14px]">
              <span className="font-semibold inline-block pe-2  mr-2">
                Bar code:
              </span>{" "}
              456
            </li>
          </ul>
        </div>
        </div>
      </div>
    </div>
  );
};

export default ProductSection;
